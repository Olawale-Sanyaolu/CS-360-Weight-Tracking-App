package com.example.weighttrackingui;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracking.db";
    private static final int DATABASE_VERSION = 2;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store registered user accounts.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL, " +
                "created_at TEXT DEFAULT CURRENT_TIMESTAMP)");

        // Store daily weight records for each user.
        db.execSQL("CREATE TABLE daily_weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "weight REAL NOT NULL CHECK(weight > 0), " +
                "date TEXT NOT NULL, " +
                "created_at TEXT DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(user_id) REFERENCES users(id) " +
                "ON DELETE CASCADE)");

        // Store one goal weight for each user.
        db.execSQL("CREATE TABLE goal_weight (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER UNIQUE NOT NULL, " +
                "target_weight REAL NOT NULL CHECK(target_weight > 0), " +
                "updated_at TEXT DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(user_id) REFERENCES users(id) " +
                "ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE sms_preferences (user_id INTEGER PRIMARY KEY, phone TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 0, last_notified_goal REAL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        if (oldVersion < 2) db.execSQL("CREATE TABLE IF NOT EXISTS sms_preferences (user_id INTEGER PRIMARY KEY, phone TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 0, last_notified_goal REAL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
    }
    public long register(String username, String hash) {
        android.content.ContentValues v = new android.content.ContentValues();
        v.put("username", username); v.put("password_hash", hash);
        return getWritableDatabase().insert("users", null, v);
    }
    public long authenticate(String username, String hash) {
        try (android.database.Cursor c = getReadableDatabase().rawQuery("SELECT id FROM users WHERE username=? AND password_hash=?", new String[]{username,hash})) {
            return c.moveToFirst() ? c.getLong(0) : -1;
        }
    }
    public long addWeight(long userId, double weight, String date) {
        android.content.ContentValues v = new android.content.ContentValues();
        v.put("user_id",userId); v.put("weight",weight); v.put("date",date);
        return getWritableDatabase().insert("daily_weights",null,v);
    }
    public int updateWeight(long userId,long id,double weight,String date) {
        android.content.ContentValues v=new android.content.ContentValues(); v.put("weight",weight);v.put("date",date);
        return getWritableDatabase().update("daily_weights",v,"id=? AND user_id=?",new String[]{String.valueOf(id),String.valueOf(userId)});
    }
    public int deleteWeight(long userId,long id) {return getWritableDatabase().delete("daily_weights","id=? AND user_id=?",new String[]{String.valueOf(id),String.valueOf(userId)});}
    public android.database.Cursor weights(long userId) {return getReadableDatabase().rawQuery("SELECT id,date,weight FROM daily_weights WHERE user_id=? ORDER BY date DESC,id DESC",new String[]{String.valueOf(userId)});}
    public void saveGoal(long userId,double target) {
        android.content.ContentValues v=new android.content.ContentValues();v.put("user_id",userId);v.put("target_weight",target);v.put("updated_at",java.text.DateFormat.getDateTimeInstance().format(new java.util.Date()));
        getWritableDatabase().insertWithOnConflict("goal_weight",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
    }
    public double goal(long userId) {
        try(android.database.Cursor c=getReadableDatabase().rawQuery("SELECT target_weight FROM goal_weight WHERE user_id=?",new String[]{String.valueOf(userId)})) {return c.moveToFirst()?c.getDouble(0):Double.NaN;}
    }
    public void saveSms(long userId,String phone,boolean enabled) {
        android.content.ContentValues v=new android.content.ContentValues();v.put("user_id",userId);v.put("phone",phone);v.put("enabled",enabled?1:0);
        getWritableDatabase().insertWithOnConflict("sms_preferences",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
    }
    public String smsPhone(long userId) {try(android.database.Cursor c=getReadableDatabase().rawQuery("SELECT phone FROM sms_preferences WHERE user_id=? AND enabled=1",new String[]{String.valueOf(userId)})){return c.moveToFirst()?c.getString(0):null;}}
    public String savedPhone(long userId) {try(android.database.Cursor c=getReadableDatabase().rawQuery("SELECT phone FROM sms_preferences WHERE user_id=?",new String[]{String.valueOf(userId)})){return c.moveToFirst()?c.getString(0):"";}}
    public boolean smsEnabled(long userId) {return smsPhone(userId)!=null;}
    public boolean wasNotified(long userId,double goal) {try(android.database.Cursor c=getReadableDatabase().rawQuery("SELECT last_notified_goal FROM sms_preferences WHERE user_id=?",new String[]{String.valueOf(userId)})){return c.moveToFirst()&&!c.isNull(0)&&c.getDouble(0)==goal;}}
    public void markNotified(long userId,double goal) {android.content.ContentValues v=new android.content.ContentValues();v.put("last_notified_goal",goal);getWritableDatabase().update("sms_preferences",v,"user_id=?",new String[]{String.valueOf(userId)});}
}