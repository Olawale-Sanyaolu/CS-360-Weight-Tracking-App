package com.example.weighttrackingui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class MainActivity extends Activity {
    private DatabaseHelper db;
    private long userId = -1, editingId = -1;
    private int screen = R.layout.screen_login;
    private static final int SMS_REQUEST = 12;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DatabaseHelper(this);
        db.getWritableDatabase();
        showLogin();
    }
    private void bind(int id, Runnable action) {
        View v = findViewById(id);
        if (v != null) v.setOnClickListener(w -> action.run());
    }
    private String value(int id) { return ((EditText)findViewById(id)).getText().toString().trim(); }
    private void notice(String message) {Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private void show(int layout) {screen=layout;setContentView(layout);}
    private static String hex(byte[] bytes) {
        StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format(Locale.US,"%02x",b & 0xff));return s.toString();
    }
    private static String derive(String password,byte[] salt) throws Exception {
        PBEKeySpec spec=new PBEKeySpec(password.toCharArray(),salt,120000,256);
        try {return hex(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded());}
        finally {spec.clearPassword();}
    }
    private static String newHash(String password) throws Exception {
        byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);
        return hex(salt)+":"+derive(password,salt);
    }
    private long verifyLogin(String username,String password) throws Exception {
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT id,password_hash FROM users WHERE username=?",new String[]{username})) {
            if(!c.moveToFirst())return -1;
            String[] parts=c.getString(1).split(":",2);
            if(parts.length!=2 || parts[0].length()!=32)return -1;
            byte[] salt=new byte[16];for(int i=0;i<16;i++)salt[i]=(byte)Integer.parseInt(parts[0].substring(i*2,i*2+2),16);
            boolean match=MessageDigest.isEqual(derive(password,salt).getBytes(java.nio.charset.StandardCharsets.UTF_8),parts[1].getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return match?c.getLong(0):-1;
        }
    }
    private void showLogin() {
        userId=-1;show(R.layout.screen_login);
        bind(R.id.createAccount,()->{
            String username=value(R.id.username),password=value(R.id.password);
            if(username.length()<3 || password.length()<8){notice("Use at least 3 username characters and 8 password characters.");return;}
            try {
                long id=db.register(username,newHash(password));
                if(id<0){notice("Username already exists. Choose another or log in.");return;}
                userId=id;notice("Account created.");showHome();
            }catch(Exception ex){notice("Unable to create account: "+ex.getClass().getSimpleName());}
        });
        bind(R.id.login,()->{
            String username=value(R.id.username),password=value(R.id.password);
            if(username.isEmpty()||password.isEmpty()){notice("Enter your username and password.");return;}
            try {long id=verifyLogin(username,password);if(id<0){notice("Incorrect username or password.");return;}userId=id;showHome();}
            catch(Exception ex){notice("Unable to log in: "+ex.getClass().getSimpleName());}
        });
    }
    private TextView cell(String text) {
        TextView t=new TextView(this);t.setText(text);t.setPadding(8,12,8,12);t.setTextSize(14);return t;
    }
    private void showHome() {
        if(userId<0){showLogin();return;}
        show(R.layout.screen_home);
        double goal=db.goal(userId);
        ((TextView)findViewById(R.id.goalSummary)).setText(Double.isNaN(goal)?"Goal: not set":"Goal: "+goal+" lb");
        TableLayout table=findViewById(R.id.historyTable);
        TableRow heading=new TableRow(this);
        for(String label:new String[]{"Date","Weight","Actions"})heading.addView(cell(label));table.addView(heading);
        try(Cursor c=db.weights(userId)) {
            if(c.getCount()==0){TableRow empty=new TableRow(this);empty.addView(cell("No entries yet. Add your first weight."));table.addView(empty);}
            while(c.moveToNext()){
                long id=c.getLong(0);String date=c.getString(1);double weight=c.getDouble(2);
                TableRow row=new TableRow(this);row.addView(cell(date));row.addView(cell(weight+" lb"));
                android.widget.LinearLayout actions=new android.widget.LinearLayout(this);
                actions.setOrientation(android.widget.LinearLayout.VERTICAL);
                Button edit=new Button(this);edit.setText("Edit");edit.setOnClickListener(v->showWeight(id,date,weight));actions.addView(edit);
                Button delete=new Button(this);delete.setText("Delete");delete.setOnClickListener(v -> {
                    Toast.makeText(this, "Delete button clicked",
                            Toast.LENGTH_SHORT).show();

                    new AlertDialog.Builder(this)
                            .setMessage("Delete this weight entry?")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Delete", (d, w) -> {
                                db.deleteWeight(userId, id);
                                showHome();
                            })
                            .show();
                });

                actions.addView(delete);
                row.addView(actions);
                table.addView(row);
            }
        }
        bind(R.id.addWeight,()->showWeight(-1,"",0));
        bind(R.id.goal,()->showGoal());bind(R.id.smsSettings,()->showSms());bind(R.id.logout,()->showLogin());
    }
    private void showWeight(long id,String date,double weight) {
        editingId=id;show(R.layout.screen_add_weight);
        ((EditText)findViewById(R.id.entryDate)).setText(id<0?new SimpleDateFormat("MM/dd/yyyy",Locale.US).format(new Date()):date);
        if(id>=0)((EditText)findViewById(R.id.weight)).setText(String.valueOf(weight));
        bind(R.id.cancelWeight,()->showHome());
        bind(R.id.saveWeight,()->{
            try {
                double w=Double.parseDouble(value(R.id.weight));String day=value(R.id.entryDate);
                if(!Double.isFinite(w)||w<=0||w>2000){notice("Enter a valid weight in pounds.");return;}
                SimpleDateFormat f=new SimpleDateFormat("MM/dd/yyyy",Locale.US);f.setLenient(false);
                Date parsed=f.parse(day);if(parsed==null||!f.format(parsed).equals(day)){notice("Use MM/DD/YYYY date format.");return;}
                if(editingId<0){if(db.addWeight(userId,w,day)<0){notice("Could not save weight.");return;}}
                else if(db.updateWeight(userId,editingId,w,day)==0){notice("Entry not found.");return;}
                checkGoal(w);showHome();
            }catch(Exception e){notice("Enter a valid weight and date (MM/DD/YYYY).");}
        });
    }
    private void showGoal() {
        show(R.layout.screen_goal);double existing=db.goal(userId);
        if(!Double.isNaN(existing))((EditText)findViewById(R.id.targetWeight)).setText(String.valueOf(existing));
        bind(R.id.backGoal,()->showHome());
        bind(R.id.saveGoal,()->{
            try {double goal=Double.parseDouble(value(R.id.targetWeight));if(!Double.isFinite(goal)||goal<=0||goal>2000){notice("Enter a valid target weight.");return;}
                db.saveGoal(userId,goal);notice("Goal saved.");showHome();}
            catch(Exception e){notice("Enter a valid target weight.");}
        });
    }
    private void showSms() {
        show(R.layout.screen_sms);
        ((EditText)findViewById(R.id.phoneNumber)).setText(db.savedPhone(userId));
        status(db.smsEnabled(userId)?"SMS enabled for saved number":"SMS is disabled");
        bind(R.id.backSms,()->showHome());
        bind(R.id.declineSms,()->{db.saveSms(userId,db.savedPhone(userId),false);status("SMS disabled; weight tracking remains available.");});
        bind(R.id.requestSms,()->{
            String phone=value(R.id.phoneNumber);
            if(!Pattern.matches("\\+?[0-9 ()-]{7,20}",phone)||phone.replaceAll("\\D","").length()<7){status("Enter a valid recipient phone number.");return;}
            if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.SEND_SMS},SMS_REQUEST);return;}
            db.saveSms(userId,phone,true);status("SMS enabled for "+phone);
        });
    }
    private void status(String message) {TextView t=findViewById(R.id.smsStatus);if(t!=null)t.setText(message);}
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==SMS_REQUEST){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED){
            String phone=value(R.id.phoneNumber);if(Pattern.matches("\\+?[0-9 ()-]{7,20}",phone)){db.saveSms(userId,phone,true);status("SMS enabled for "+phone);}else status("Enter a valid phone number.");
        }else status("SMS permission denied; tracking remains available.");}
    }
    private void checkGoal(double weight) {
        double goal=db.goal(userId);String phone=db.smsPhone(userId);
        if(Double.isNaN(goal)||weight>goal||phone==null||db.wasNotified(userId,goal))return;
        if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){notice("Goal reached! SMS permission is not granted.");return;}
        try {
            SmsManager.getDefault().sendTextMessage(phone,null,"Congratulations! You reached your Weight Tracker goal of "+goal+" lb.",null,null);
            db.markNotified(userId,goal);notice("Goal reached! SMS handed to the device for sending (delivery not confirmed).");
        }catch(Exception e){notice("Goal reached, but SMS could not be sent: "+e.getClass().getSimpleName());}
    }
    @Override public void onBackPressed(){if(screen==R.layout.screen_login)super.onBackPressed();else if(screen==R.layout.screen_home)showLogin();else showHome();}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
