# CS 360 Project Two — Option 3: Weight-Tracking App
Olawale Sanyaolu

Open this folder in Android Studio and allow Gradle to sync. Run the app on an Android emulator or phone. Five native XML layouts are in app/src/main/res/layout. The Java activity supports preview navigation and the runtime SMS permission request; authentication, database persistence, row deletion, and SMS sending are deliberately deferred to Project Three. The history table displays illustrative sample data. Login and Create Account navigate to the preview only; they do not authenticate or save credentials. Delete buttons are visual placeholders.

Project Two rubric mapping: login fields (password masked) and buttons; history grid with headers and per-row Delete buttons; add-weight date and numeric weight input; goal input; SMS permission screen and optional telephony/SEND_SMS manifest declarations; consistent theme and Back navigation.

Note: A Gradle wrapper binary is not bundled; open the project in Android Studio, which can use its installed Gradle distribution. If prompted, configure Gradle in Android Studio settings.
